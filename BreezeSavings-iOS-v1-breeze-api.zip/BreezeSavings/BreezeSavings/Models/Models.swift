import Foundation

struct Record: Codable, Identifiable, Hashable {
    let id: Int
    let date: String
    let type: String
    let amount: Double
    let note: String
    var category: String?
    var isIncome: Bool { type == "income" }
}

struct PlanSettings: Codable { var goal: Double; var start_month: String; var end_month: String }
struct RecordsResponse: Codable { let ok: Bool; let records: [Record]; let settings: PlanSettings }
struct CreateRecordResponse: Codable { let ok: Bool; let id: Int? }
struct SettingsResponse: Codable { let ok: Bool; let settings: PlanSettings }
struct Memory: Codable, Identifiable { let id: Int; let content: String; let created_at: String? }
struct FinanceResponse: Codable { let ok: Bool; let budgets: [String: Double]; let memories: [Memory] }
struct AIResponse: Codable { let ok: Bool; let reply: String?; let report: String?; let parsed_records: [ParsedRecord]? }
struct ParsedRecord: Codable { let date: String; let type: String; let amount: Double; let note: String }
