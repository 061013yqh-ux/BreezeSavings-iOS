import SwiftUI

@main
struct BreezeSavingsApp: App {
    @StateObject private var store = FinanceStore()
    var body: some Scene {
        WindowGroup { RootView().environmentObject(store).task { await store.load() } }
    }
}
