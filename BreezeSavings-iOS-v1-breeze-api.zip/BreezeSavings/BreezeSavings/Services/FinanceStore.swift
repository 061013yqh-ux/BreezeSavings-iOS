import Foundation
import SwiftUI

@MainActor final class FinanceStore: ObservableObject {
    @Published var records:[Record] = []
    @Published var settings = PlanSettings(goal:15000,start_month:"2026-08",end_month:"2027-01")
    @Published var budgets:[String:Double] = [:]
    @Published var memories:[Memory] = []
    @Published var isLoading=false
    @Published var error:String?
    let api = APIClient.shared
    var income:Double { records.filter(\.isIncome).reduce(0){$0+$1.amount} }
    var expense:Double { records.filter{!$0.isIncome}.reduce(0){$0+$1.amount} }
    var saved:Double { income-expense }
    var progress:Double { settings.goal > 0 ? max(0,min(saved/settings.goal,1)) : 0 }

    func load() async { isLoading=true; defer{isLoading=false}; do { let r=try await api.records(); records=r.records; settings=r.settings; let f=try? await api.finance(); budgets=f?.budgets ?? [:]; memories=f?.memories ?? [] } catch { self.error=error.localizedDescription } }
    func add(date:Date,type:String,amount:Double,note:String) async throws { let f=DateFormatter(); f.dateFormat="yyyy-MM-dd"; _ = try await api.add(date:f.string(from:date),type:type,amount:amount,note:note); await load() }
    func delete(_ record:Record) async { do { _ = try await api.delete(id:record.id); await load() } catch { self.error=error.localizedDescription } }
    func savePlan() async throws { let r=try await api.savePlan(settings); settings=r.settings }
    func sendAI(_ text:String) async throws -> String { let r=try await api.chat(text); if let parsed=r.parsed_records { for x in parsed { _ = try await api.add(date:x.date,type:x.type,amount:x.amount,note:x.note) }; await load() }; return r.reply ?? "AI 暂时没有返回内容。" }
}
