import Foundation

enum APIError: LocalizedError { case invalidURL, server(String); var errorDescription: String? { switch self { case .invalidURL: return "服务器地址无效"; case .server(let s): return s } } }

final class APIClient {
    static let shared = APIClient()
    // Breeze 后端 / Cloudflare Pages API
    let baseURL = "https://breeze-bid.pages.dev"
    private let decoder = JSONDecoder()

    private func request<T: Decodable>(_ path: String, method: String = "GET", body: Encodable? = nil) async throws -> T {
        guard let url = URL(string: baseURL + path) else { throw APIError.invalidURL }
        var req = URLRequest(url: url); req.httpMethod = method; req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if let body { req.httpBody = try JSONEncoder().encode(AnyEncodable(body)) }
        let (data, response) = try await URLSession.shared.data(for: req)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any]
            throw APIError.server(obj?["error"] as? String ?? "服务器请求失败")
        }
        return try decoder.decode(T.self, from: data)
    }

    func records() async throws -> RecordsResponse { try await request("/api/records") }
    func add(date: String, type: String, amount: Double, note: String) async throws -> CreateRecordResponse { try await request("/api/records", method:"POST", body: AddBody(date:date,type:type,amount:amount,note:note)) }
    func delete(id: Int) async throws -> EmptyResponse { try await request("/api/records?id=\(id)", method:"DELETE") }
    func savePlan(_ s: PlanSettings) async throws -> SettingsResponse { try await request("/api/records?settings=1", method:"PUT", body:s) }
    func finance() async throws -> FinanceResponse { try await request("/api/finance") }
    func chat(_ message: String) async throws -> AIResponse { try await request("/api/ai", method:"POST", body:AIBody(mode:"chat", message:message)) }
    func manager() async throws -> AIResponse { try await request("/api/ai", method:"POST", body:AIBody(mode:"auto_manager", message:nil)) }
}
private struct AddBody: Encodable { let date,type:String; let amount:Double; let note:String }
private struct AIBody: Encodable { let mode:String; let message:String? }
struct EmptyResponse: Decodable { let ok: Bool }
private struct AnyEncodable: Encodable { let encodeClosure:(Encoder)throws->Void; init(_ value: Encodable){ encodeClosure=value.encode }; func encode(to encoder: Encoder)throws{try encodeClosure(encoder)} }
