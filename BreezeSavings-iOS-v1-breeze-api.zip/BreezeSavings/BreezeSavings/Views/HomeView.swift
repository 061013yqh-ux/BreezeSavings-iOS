import SwiftUI

struct HomeView: View {
    @EnvironmentObject var store:FinanceStore
    var body: some View {
        ScrollView { VStack(spacing:18) {
            VStack(alignment:.leading,spacing:14) {
                HStack { VStack(alignment:.leading){ Text("我的目标").font(.caption); Text("攒钱计划").font(.title2.bold()) }; Spacer(); ZStack { Circle().stroke(.white.opacity(0.3),lineWidth:8); Circle().trim(from:0,to:store.progress).stroke(.white,lineWidth:8).rotationEffect(.degrees(-90)); Text("\(Int(store.progress*100))%").bold() }.frame(width:74,height:74) }
                Text(store.saved,format:.currency(code:"CNY")).font(.system(size:34,weight:.bold))
                HStack { stat("距离目标", max(store.settings.goal-store.saved,0)); Spacer(); stat("目标金额",store.settings.goal) }
            }.foregroundStyle(.white).padding(22).background(LinearGradient(colors:[.green,.mint],startPoint:.topLeading,endPoint:.bottomTrailing),in:RoundedRectangle(cornerRadius:26))
            HStack { Summary(title:"收入",value:store.income,icon:"arrow.down.circle.fill"); Summary(title:"支出",value:store.expense,icon:"arrow.up.circle.fill") }
            VStack(alignment:.leading,spacing:12) { HStack{Text("最近收支").font(.title3.bold());Spacer();}; ForEach(store.records.prefix(5)){ r in RecordRow(record:r); Divider() } }.padding().background(.background,in:RoundedRectangle(cornerRadius:20)).shadow(color:.black.opacity(0.05),radius:12)
        }.padding() }.navigationTitle("攒钱计划").refreshable{await store.load()}.alert("提示",isPresented:.constant(store.error != nil)){Button("好"){store.error=nil}} message:{Text(store.error ?? "")}
    }
    func stat(_ t:String,_ v:Double)->some View { VStack(alignment:.leading){Text(t).font(.caption);Text(v,format:.currency(code:"CNY")).bold()} }
}
struct Summary:View { let title:String;let value:Double;let icon:String; var body:some View { HStack{Image(systemName:icon).font(.title2).foregroundStyle(.green);VStack(alignment:.leading){Text(title).font(.caption).foregroundStyle(.secondary);Text(value,format:.currency(code:"CNY")).bold()};Spacer()}.padding().background(.background,in:RoundedRectangle(cornerRadius:18)) } }
struct RecordRow:View { let record:Record; var body:some View { HStack { Image(systemName:record.isIncome ? "arrow.down" : "cart").frame(width:38,height:38).background((record.isIncome ? Color.green : Color.orange).opacity(.12),in:Circle()).foregroundStyle(record.isIncome ? .green:.orange); VStack(alignment:.leading){Text(record.note.isEmpty ? (record.category ?? "其他") : record.note).bold();Text("\(record.date) · \(record.category ?? "其他")").font(.caption).foregroundStyle(.secondary)};Spacer();Text(record.amount,format:.currency(code:"CNY")).foregroundStyle(record.isIncome ? .green:.red).bold() } } }
