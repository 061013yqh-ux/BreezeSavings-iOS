import SwiftUI
struct RecordsView:View {
 @EnvironmentObject var store:FinanceStore; @State var showAdd=false; @State var filter="all"
 var filtered:[Record]{ filter=="all" ? store.records : store.records.filter{$0.type==filter} }
 var body:some View { List { Picker("筛选",selection:$filter){Text("全部").tag("all");Text("收入").tag("income");Text("支出").tag("expense")}.pickerStyle(.segmented); ForEach(filtered){r in RecordRow(record:r).swipeActions{Button(role:.destructive){Task{await store.delete(r)}} label:{Label("删除",systemImage:"trash")}}} }.navigationTitle("收支记录").toolbar{Button{showAdd=true}label:{Image(systemName:"plus.circle.fill")}}.sheet(isPresented:$showAdd){AddRecordView()} }
}
struct AddRecordView:View {
 @EnvironmentObject var store:FinanceStore; @Environment(\.dismiss) var dismiss; @State var type="expense";@State var amount="";@State var note="";@State var date=Date();@State var saving=false
 var body:some View { NavigationStack{Form{Picker("类型",selection:$type){Text("支出").tag("expense");Text("收入").tag("income")}.pickerStyle(.segmented);TextField("金额",text:$amount).keyboardType(.decimalPad);TextField("备注，例如午餐",text:$note);DatePicker("日期",selection:$date,displayedComponents:.date)}.navigationTitle("记一笔").toolbar{ToolbarItem(placement:.cancellationAction){Button("取消"){dismiss()}};ToolbarItem(placement:.confirmationAction){Button("保存"){Task{saving=true;try? await store.add(date:date,type:type,amount:Double(amount) ?? 0,note:note);saving=false;dismiss()}}.disabled((Double(amount) ?? 0)<=0 || saving)}}} }
}
