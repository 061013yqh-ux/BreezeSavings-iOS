import SwiftUI
struct AIView:View {
 @EnvironmentObject var store:FinanceStore;@State var text="";@State var messages:[ChatMessage]=[.init(role:"ai",text:"你好，我是你的 AI 财务管家。你可以直接说：今天午饭花了35，工资收入5000。")];@State var sending=false
 var body:some View { VStack { ScrollViewReader{proxy in ScrollView{LazyVStack(spacing:12){ForEach(messages){m in HStack{if m.role=="user"{Spacer()};Text(m.text).padding(12).background(m.role=="user" ? Color.green : Color(.secondarySystemBackground),in:RoundedRectangle(cornerRadius:16)).foregroundStyle(m.role=="user" ? .white:.primary);if m.role=="ai"{Spacer()}}.id(m.id)}}.padding()}.onChange(of:messages.count){_,_ in if let id=messages.last?.id{withAnimation{proxy.scrollTo(id,anchor:.bottom)}}}}; HStack{TextField("对我说点什么…",text:$text,axis:.vertical).textFieldStyle(.roundedBorder);Button{send()}label:{Image(systemName:"arrow.up.circle.fill").font(.title).foregroundStyle(.green)}}.padding() }.navigationTitle("AI 管家")
 }
 func send(){let q=text.trimmingCharacters(in:.whitespacesAndNewlines);guard !q.isEmpty,!sending else{return};text="";messages.append(.init(role:"user",text:q));sending=true;Task{do{let r=try await store.sendAI(q);messages.append(.init(role:"ai",text:r))}catch{messages.append(.init(role:"ai",text:"请求失败：\(error.localizedDescription)"))};sending=false}}
}
struct ChatMessage:Identifiable{let id=UUID();let role:String;let text:String}
