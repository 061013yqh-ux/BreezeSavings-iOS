import SwiftUI

struct RootView: View {
    var body: some View {
        TabView {
            NavigationStack { HomeView() }.tabItem { Label("首页", systemImage:"house.fill") }
            NavigationStack { RecordsView() }.tabItem { Label("记账", systemImage:"square.and.pencil") }
            NavigationStack { AIView() }.tabItem { Label("AI 管家", systemImage:"bubble.left.and.bubble.right.fill") }
            NavigationStack { ProfileView() }.tabItem { Label("我的", systemImage:"person.fill") }
        }.tint(.green)
    }
}
